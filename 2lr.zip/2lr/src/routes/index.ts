export { default as CompeticaoRoutes } from "./competicao.routes";
export { default as PartidasRoutes } from "./partidas.routes";
export { default as EquipesRoutes } from "./equipes.routes";
export { default as EstadiosRoutes } from "./estadios.routes";
export { default as JogadoresLinhaRoutes } from "./jogadoresLinha.routes";
export { default as GoleirosRoutes } from "./goleiros.routes";
export { default as ComissaoTecnicaRoutes } from "./comissaoTecnica.routes";
